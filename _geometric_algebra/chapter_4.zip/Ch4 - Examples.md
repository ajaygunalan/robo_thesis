---
title: "Ch4 - Examples"
tags: [examples, scaling, rotation, projection, reflection]
---

# Ch4 - Examples

Outermorphism thinking is: **apply `f` to vectors, then wedge**.

## Uniform scaling
If `S(x)=αx`, then for `A=a₁∧…∧a_k`:
`S(A)=α^k A`.
So areas scale by `α²`, volumes by `α³`, and orientation flips when `k` is odd and `α<0`.

## Parallel projection onto a line (the important surprise)
In a plane spanned by `a,b`, take `P(a)=a`, `P(b)=0`. The plane’s *vector set* maps onto the `a`-line, but the **2-blade** maps to
`P(a∧b)=P(a)∧P(b)=a∧0=0`.
Projection kills **area elements**, not just directions.

## Rotation and an eigenblade
Rotate in the `u∧v` plane. Vectors rotate, yet the plane blade is fixed:
`R(u∧v)=R(u)∧R(v)=u∧v`.
A rotation may have no real eigenvectors in its plane, but it has a real eigen-**2-blade**: the plane itself.

## Point reflection
`f(x)=-x` ⇒ `f(A)=(-1)^{grade(A)}A`. In 3D that flips 3-blade handedness.

## Orthogonal projection (why outermorphisms are practical)
The vector projection `P_B(x)=((x⟂B)⟂B^{-1})` extends cleanly: you can project a blade directly without decomposing it into vectors.

These examples feed directly into the geometric definition of [[Ch4 - Determinant]] and the metric-aware rules in [[Ch4 - Metric Products]].
