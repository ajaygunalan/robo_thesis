---
title: "Chapter 4 - Linear Transformations of Subspaces"
tags: [geometric-algebra, linear-transformations, blades, outermorphism]
---

# Chapter 4 - Linear Transformations of Subspaces

Linear maps are taught as “things that move vectors around.” Geometry, however, lives in **subspaces**—lines, planes, volumes—and in GA those are **blades**. This chapter’s goal is to stop decomposing subspaces into vectors just to transform them: extend a linear map so it acts on blades *directly*.

The opening intuition is almost unavoidable: a blade is a *span-with-orientation*. If `A = a₁∧…∧a_k`, then transforming the subspace should mean “transform the generators, then re-span.” That single demand becomes the [[Ch4 - Outermorphisms]] rule `f(A∧B)=f(A)∧f(B)`.

Once ∧ is handled, you peel into the metric:
- Top-grade blades track signed hypervolume, so `f(I_n)=det(f)I_n` defines the [[Ch4 - Determinant]].
- Contractions and duals depend on the inner product, so you need the **adjoint** (transpose in Euclidean coordinates), giving the product laws in [[Ch4 - Metric Products]].
- Those laws pay off as a compact, coordinate-free [[Ch4 - Inverses]] formula.
- Matrices then reappear as a basis-bound implementation layer in [[Ch4 - Matrix Representations]].

## What to remember
- **Outermorphism:** `f(α)=α`, `f(A+B)=f(A)+f(B)`, `f(A∧B)=f(A)∧f(B)`.
- **Determinant:** `f(I_n)=det(f)I_n`.
- **Adjoint:** `⟨f(a),b⟩=⟨a,f†(b)⟩`.
- **Contraction:** `f(A⟂B)=(f†)^{-1}(A)⟂f(B)` (orthogonal ⇒ structure-preserving).

The chapter’s punchline: ∧-structure survives any linear map; ⟂-structure survives exactly the orthogonal ones.
