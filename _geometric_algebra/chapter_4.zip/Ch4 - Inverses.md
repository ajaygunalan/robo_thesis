---
title: "Ch4 - Inverses"
tags: [inverse, duality, determinant]
---

# Ch4 - Inverses

The contraction law is the leverage: it lets you express `f^{-1}` without coordinates by pushing information through the pseudoscalar.

## Coordinate-free inverse
For an invertible `f` and any blade/multivector `A`:
`f^{-1}(A) = ( f(A ⟂ I_n^{-1}) ⟂ I_n ) / det(f)`.

In dual form:
`(f^{-1}(A))* = f(A*) / det(f)`.

## Quick checks
- `f^{-1}(I_n)=I_n/det(f)` ⇒ `det(f^{-1})=1/det(f)`.
- Scalars are fixed: `f^{-1}(α)=α`.
- For vectors, expanding on a basis reproduces the classical “adjugate over determinant” pattern—but this formula also works for higher grades automatically.

Although the expression uses duality, the two dualizations cancel the metric dependence: the inverse is a property of the linear map itself. Matrices are just one way to implement it efficiently in [[Ch4 - Matrix Representations]].
