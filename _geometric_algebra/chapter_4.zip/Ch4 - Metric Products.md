---
title: "Ch4 - Metric Products"
tags: [adjoint, contraction, orthogonal, duals, normals]
---

# Ch4 - Metric Products

∧ is “span,” so it doesn’t care about the metric. ⟂ and duality do: they encode perpendicularity and complements, so linear maps won’t preserve them unless they have extra structure.

## Scalars don’t transform; norms can
Because scalars are fixed by the extension, if a product *outputs* a scalar:
`f(A*B)=A*B`.
But the norm of a transformed blade is `f(A)*f(A)`, which generally changes—nothing forces `f` to preserve angles or lengths.

## The adjoint `f†`
To control metric behavior, define `f†` by
`⟨f(a), b⟩ = ⟨a, f†(b)⟩` for all vectors `a,b`.
In Euclidean orthonormal coordinates, `f†` is the transpose map. Extend it to blades as an outermorphism, so `f†(A)*B = A*f(B)`.

## Contraction transforms with the adjoint
The compact law is:
`f(A⟂B) = (f†)^{-1}(A) ⟂ f(B)`.

## Orthogonal transformations are exactly the nice ones
If `⟨f(a),f(b)⟩=⟨a,b⟩`, then `f†=f^{-1}` and contraction becomes structure-preserving:
`f(A⟂B)=f(A)⟂f(B)`.

## Duals (and “normal vectors”) transform differently
With `X* = X⟂I_n^{-1}`, duals inherit both the adjoint and determinant:
`f⋆(X*) = (f(X))* = det(f)\,(f†)^{-1}(X*)`.
That’s why a 3D normal `a×b` (a dual of `a∧b`) does **not** generally transform as `f(a)×f(b)`; using the bivector `a∧b` avoids that trap.

These rules are the machinery behind the coordinate-free inverse in [[Ch4 - Inverses]].
