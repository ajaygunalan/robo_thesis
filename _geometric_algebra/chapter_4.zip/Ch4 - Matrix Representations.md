---
title: "Ch4 - Matrix Representations"
tags: [matrices, basis, reciprocal-frame, implementation]
---

# Ch4 - Matrix Representations

A matrix is a linear transformation *seen through a chosen basis*. That choice is why matrices are efficient and also why they hide geometry.

## Vector matrix
Given a basis `{b_i}` with reciprocal `{b^j}` (`b_i·b^j=δ_i^j`), define
`[f]^j_i = f(b_i) · b^j`.
The `i`th column is the image of `b_i` written in that coordinate system.

## Outermorphism matrices (one per grade)
On `k`-vectors, pick the blade basis `b_I = b_{i1}∧…∧b_{ik}` with reciprocal `b^I`. Then
`[f]^J_I = f(b_I) * b^J`.

For bivectors this expands to the familiar 2×2 minor pattern:
`[f]^{j1j2}_{i1i2} = [f]^{j2}_{i2}[f]^{j1}_{i1} - [f]^{j1}_{i2}[f]^{j2}_{i1}`.

So “transforming areas/volumes” in coordinates is literally “taking minors,” which matches the geometric meaning of ∧.

## Practical note
If you apply the same `f` many times, precomputing these outermorphism matrices can beat recomputing wedge/contraction expressions. Conceptually, it’s still the same object as [[Ch4 - Outermorphisms]]—just compiled into coordinates.
