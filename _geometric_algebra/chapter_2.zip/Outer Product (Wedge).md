---
title: "Outer Product (Wedge)"
tags: [outer-product, blades, determinants]
---

You want an element that *is* “the oriented subspace spanned by these vectors”. The outer product `∧` is defined almost entirely by that demand.

## The defining behaviors
- **Antisymmetry (vectors)**: `a ∧ b = -b ∧ a` (so `a ∧ a = 0`).
- **Bilinearity**: distribute over `+`, pull out scalars.
- **Associativity**: no parentheses needed in `a ∧ b ∧ c`.

Those rules make `a ∧ b` an oriented area element (a 2-blade) and `a ∧ b ∧ c` an oriented volume element (a 3-blade).

## Determinants are the coefficient story
Expand `a ∧ b` in a basis and the coefficients are 2×2 determinants; expand `a ∧ b ∧ c` in `R^3` and you get the 3×3 determinant. The wedge keeps the *geometric unit* (like `e1 ∧ e2`) attached instead of collapsing everything to a scalar.

## Zero is an incidence test
- `a ∧ b = 0` ⇔ dependence / parallelness.
- `x ∧ a = 0` is a line equation.
- `x ∧ B = 0` is a plane equation (for a 2-blade `B`).

This is the algebraic backbone of [[Geometric Properties]].

## Swapping higher grades
For a `k`-blade `A_k` and `l`-blade `B_l`:
- `A_k ∧ B_l = (-1)^{kl} B_l ∧ A_k`.

Only odd-with-odd swaps negate. That’s why scalar wedge multiplication behaves like ordinary multiplication without contradicting antisymmetry.
