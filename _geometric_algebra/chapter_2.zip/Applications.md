---
title: "Applications"
tags: [cramers-rule, line-intersection, incidence, computation]
---

The wedge turns “solve/intersect/test” into computations with oriented subspaces.

## Decomposing vectors (Cramer’s rule, without coordinates)
In `R^2`, solve `x = αa + βb` by wedging with `a` and `b`:
- `x ∧ a = β(b ∧ a)`
- `x ∧ b = α(a ∧ b)`

So the coefficients are ratios of oriented areas:
- `α = (x ∧ b)/(a ∧ b)`, `β = (x ∧ a)/(b ∧ a)`,

and
- `x = ((x ∧ b)/(a ∧ b)) a + ((x ∧ a)/(b ∧ a)) b`.

Determinants appear only if you choose to expand wedges in a basis.

## Intersecting planar lines via reshapeability
For `L: p + t u` and `M: q + s v`, at intersection `x` you can replace unknown bivectors by anchored ones in the same attitude:
- `x ∧ u = p ∧ u`, `x ∧ v = q ∧ v`.

Then the same ratio logic yields:
- `x = (q ∧ v)/(u ∧ v) u + (p ∧ u)/(v ∧ u) v`.

## Incidence as equations
- parallel test: `a ∧ b = 0`,
- line equation: `x ∧ a = 0`,
- plane equation (2-blade `B`): `x ∧ B = 0`.

## Programmer-grade uses
- **Triangle orientation** in 2D: sign of `(b-a) ∧ (c-a)` drives back-face culling.
- **Vector-field singularities** in 3D: normalize samples on a cube to the unit sphere, sum small spherical triangle contributions `v(p1) ∧ v(p2) ∧ v(p3)`; near-unit total suggests a singularity inside, near-zero suggests none.

Everything above is the same move: compute with blades instead of re-deriving geometry from coordinates.
