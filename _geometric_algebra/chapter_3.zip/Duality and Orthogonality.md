---
title: "Duality and Orthogonality"
tags: [geometric-algebra, duality, orthogonality]
---

Orthogonality is usually a yes/no relation. In this chapter it becomes a *construction*: contraction produces the part of a subspace that’s forced to be perpendicular to another. Duality is the cleanest version of that idea—orthogonality relative to the whole space.

## Layer 1 — why contraction composition matters
Contraction can’t be associative in general (grades won’t even match), so you need the *right* composition law.

Two identities are the ones that actually behave geometrically:
- Always valid:
  \[
  (A\wedge B)\⌋C = A\⌋(B\⌋C)
  \]
  Read it as: “perpendicular-to-\(A\) and perpendicular-to-\(B\)” is the same as “perpendicular-to-\(A\wedge B\).”
- Conditionally (when \(A\subseteq C\)):
  \[
  (A\⌋B)\⌋C = A\wedge(B\⌋C)
  \]
  This is the “we removed \(A\), then put it back” trick—but only if \(C\) already had \(A\) available to reconstruct.

## Layer 2 — an inverse that’s good enough
A blade doesn’t have a unique inverse under contraction (you can always add something perpendicular and keep \(A\⌋A^{-1}=1\)). But there *is* a canonical one:
\[
A^{-1} = \frac{\tilde A}{A^2}
\]
(up to the grade-dependent sign coming from reversion conventions). It satisfies \(A\⌋A^{-1}=1\) when \(A^2\neq 0\). Null blades (zero norm) are the warning label: the inverse doesn’t exist there.

## Layer 3 — dualization is “contract with the pseudoscalar”
Let \(I_n\) be the unit pseudoscalar of the ambient space. The dual of a *k*-blade is
\[
A^* = A\⌋I_n^{-1}
\]
Geometrically: \(A^*\) represents the **orthogonal complement** of the subspace of \(A\), with a consistent orientation (Figures 3.4 and 3.5 are the 2-D and 3-D intuition pumps).

Dualizing twice flips a dimension-dependent sign:
\[
(A^*)^* = (-1)^{n(n-1)/2}A
\]
So if you need a true “undo,” use undualization:
\[
A^{-\!*}=A\⌋I_n
\]

## Layer 4 — duality turns wedges into contractions (and back)
With \(I_n\) as the “everything blade,” both subspaces are automatically contained in it, so duality identities become powerful simplifiers:
\[
(A\wedge B)^* = A\⌋(B^*)
\]
and, when containment is satisfied,
\[
(A\⌋B)^* = A\wedge(B^*)
\]

## Layer 5 — dual representation of a subspace (membership test, metric-flavored)
Direct representation: \(A\) represents a subspace via \(x\in A\iff x\wedge A=0\).

Dual representation: let \(D=A^*\). Then
\[
x\in A\iff x\⌋D=0
\]
That \(D\) is also a direct representation of the orthogonal complement of \(A\). This is the general-blade version of the “normal vector defines a hyperplane by \(x\cdot n=0\)” habit—now upgraded to arbitrary dimension.

With duality in place, “do geometry” becomes “apply a product, maybe dualize to swap wedge/contract, then undualize.” The next note shows that in action on projections and coordinates: [[Geometric Operations]].
