---
title: "Geometric Operations"
tags: [geometric-algebra, projection, coordinates]
---

Once you can (1) remove components via [[Contraction (⌋)]], (2) normalize blades via inverses, and (3) swap span/complement via [[Duality and Orthogonality]], most “linear algebra geometry” becomes a short formula.

## Orthogonal projection (vectors and blades)
A projection should keep what lies in \(B\) and kill what’s perpendicular to \(B\). The contraction already manufactures the “in \(B\), perpendicular to \(x\)” piece; dualizing within \(B\) turns that into the actual projected component.

For a vector:
\[
P_B[x] = (x\⌋B)\⌋B^{-1}
\]
For a blade \(X\) of any grade:
\[
P_B[X] = (X\⌋B)\⌋B^{-1}
\]
It’s idempotent: applying it twice doesn’t change anything.

A practical variant that makes “the result lies in \(B\)” visually obvious is
\[
P_B[X] = (X\⌋B^{-1})\⌋B
\]
This matters most when inverses misbehave (e.g., null blades in degenerate metrics).

A useful perspective flip: contraction is the “dual-by-\(B\)” of a projection:
\[
X\⌋B = P_B[X]\⌋B
\]
So if projection feels intuitive and contraction feels alien, you can *bootstrap* your intuition that way.

## Reciprocal frames (coordinates without orthonormality)
With a skew basis \(\{b_i\}\), dotting with \(b_i\) doesn’t isolate coordinates. The fix is to build a *reciprocal basis* \(\{b^i\}\) that is mutually orthonormal with \(\{b_i\}\).

Let \(I_n=b_1\wedge\dots\wedge b_n\). Define
\[
b^i = (-1)^{i-1}(b_1\wedge\dots\wedge \widehat{b_i}\wedge\dots\wedge b_n)\⌋I_n^{-1}
\]
Then
\[
b_i\cdot b^j = \delta_i^j
\]
and any vector \(x=\sum_i x^i b_i\) has coefficients
\[
x^i = x\cdot b^i
\]
So “take coordinates” becomes an inner product again—just with the right vectors.

The geometry hiding in the formula: \(b^i\) is the (oriented) orthogonal complement of the span of *all* basis vectors except \(b_i\). In a truly orthonormal basis this collapses to \(b^i=\pm b_i\), so you recover the usual shortcut.

These two operations—projection and reciprocal frames—are the workhorses that make later chapters feel coordinate-free without being coefficient-illiterate.
